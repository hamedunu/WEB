package ir.wwwv.fullscreenweb

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private var webView: WebView? = null
    private var launched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showAddressScreen()
        applyImmersive()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun showAddressScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER; setPadding(28,28,28,28); setBackgroundColor(Color.rgb(16,18,24)) }
        val title = TextView(this).apply { text = "باز کردن وب‌سایت"; textSize = 25f; setTextColor(Color.WHITE); gravity = android.view.Gravity.CENTER }
        val hint = TextView(this).apply { text = "آدرس سایت را وارد کنید"; textSize = 15f; setTextColor(Color.LTGRAY); gravity = android.view.Gravity.CENTER; setPadding(0,14,0,22) }
        address = EditText(this).apply {
            setSingleLine(true); textSize = 17f; hint = "https://example.com"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(16,14,16,14); setBackgroundColor(Color.rgb(39,42,51))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        val go = Button(this).apply { text = "ورود به سایت"; setOnClickListener { openAddress() } }
        address.setOnEditorActionListener { _, actionId, _ -> if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { openAddress(); true } else false }
        root.addView(title, LinearLayout.LayoutParams(-1,-2)); root.addView(hint, LinearLayout.LayoutParams(-1,-2)); root.addView(address, LinearLayout.LayoutParams(-1,-2)); root.addView(go, LinearLayout.LayoutParams(-1,-2).apply { topMargin=16 })
        setContentView(root)
    }

    private fun openAddress() {
        var url = address.text.toString().trim()
        if (url.isEmpty()) { Toast.makeText(this,"لطفاً آدرس سایت را وارد کنید",Toast.LENGTH_SHORT).show(); return }
        if (!url.contains("://")) url = "https://$url"
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) { Toast.makeText(this,"آدرس معتبر نیست",Toast.LENGTH_SHORT).show(); return }
        webView?.destroy()
        val wv = WebView(this)
        webView = wv
        wv.setBackgroundColor(Color.BLACK)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return false
                if (target.scheme == "http" || target.scheme == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW,target)) } catch (_: Exception) {}
                return true
            }
        }
        launched = true
        setContentView(wv)
        wv.loadUrl(url)
        applyImmersive()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) applyImmersive() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val wv = webView
        if (launched && wv != null && wv.canGoBack()) wv.goBack()
        else if (launched) { launched=false; showAddressScreen(); applyImmersive() }
        else super.onBackPressed()
    }
    override fun onDestroy() { webView?.destroy(); webView=null; super.onDestroy() }
}
